<?php
/* Template for Front Page */
get_header(); // ✅ This loads header.php (your navbar)
?>

<h1 class="text-center text-danger">Hello</h1>

<?php
get_footer(); // ✅ This loads footer.php
?>
